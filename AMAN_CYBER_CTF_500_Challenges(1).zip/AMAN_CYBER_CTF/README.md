# AMAN CYBER CTF — 500 Challenge Edition

A Flask + SQLite Capture The Flag learning platform. It includes 500 fictional, self-contained puzzles across Web, Cryptography, Forensics, Linux, Networking, OSINT and Misc. Challenges range from Beginner to Advanced.

## Safety and scope
- All challenge evidence is fictional and included in the platform.
- This project does not scan, exploit, or connect to third-party systems.
- Only use future added labs against systems you own or have explicit written permission to test.
- Do not expose organizer solution files on a public web server.

## Run on Kali Linux

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip unzip
unzip AMAN_CYBER_CTF.zip
cd AMAN_CYBER_CTF
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000` in your browser. Register a player account and start solving.

## Included features
- 500 challenges with category, difficulty, points, prompt and hint
- Flag checking using SHA-256 hashes (plaintext flags are not in public challenge JSON)
- Registration and login
- One-time solve tracking and points
- Leaderboard
- SQLite database created automatically
- Responsive dark-green interface

## Organizer solutions
`data/organizer_solutions.csv` contains the answer flags and short solution notes. Keep this file private. Do not upload it to a public Git repository or web root. Before publishing, move it outside the deployed application or remove it from the public build and retain a private backup.

## Public deployment (example: Render)

1. Create a private backup of `data/organizer_solutions.csv`.
2. Create a Git repository containing the app, templates, static files, requirements.txt and `data/challenges.json`. Exclude organizer_solutions.csv, local database files, and `.venv`.
3. Create a web service on Render and connect the repository.
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Set environment variable `AMAN_SECRET_KEY` to a long, random secret value.
7. Add a persistent disk and configure SQLite storage on it if your hosting plan supports persistent disks. Otherwise use a managed PostgreSQL database before running a serious public competition; ephemeral filesystems can reset the SQLite database on redeploy.
8. Use HTTPS, backups, rate limiting, and monitoring. Test registration, submissions, and leaderboard before sharing the URL.

### Important production notes
This starter is suitable for learning and a small pilot. Before a large public event:
- Move from SQLite to managed PostgreSQL.
- Add CSRF protection, rate limiting, email verification, password reset, and admin roles.
- Add a moderation/report process and privacy notice.
- Keep organizer flags and solution notes private.
- Do not run the Flask development server on the public internet.
- Public challenge instances that execute user code or run vulnerable services require isolated containers/VMs, strict network controls, resource limits, and expert review. This starter deliberately avoids those risks.

## Project structure

```text
AMAN_CYBER_CTF/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   ├── challenges.json
│   └── organizer_solutions.csv   # private; never publish
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── auth.html
│   ├── challenges.html
│   ├── challenge.html
│   └── leaderboard.html
└── static/
    └── style.css
```
