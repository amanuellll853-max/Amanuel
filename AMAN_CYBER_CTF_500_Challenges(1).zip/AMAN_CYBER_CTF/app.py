import os, json, sqlite3, hashlib, secrets, hmac
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(ROOT, "aman_ctf.db")
DATA_PATH = os.path.join(ROOT, "data", "challenges.json")
app = Flask(__name__)
app.secret_key = os.environ.get("AMAN_SECRET_KEY") or secrets.token_hex(32)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS challenges (
      id INTEGER PRIMARY KEY, code TEXT UNIQUE, title TEXT, category TEXT,
      difficulty TEXT, points INTEGER, description TEXT, hint TEXT, flag_hash TEXT
    );
    CREATE TABLE IF NOT EXISTS solves (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, challenge_id INTEGER,
      solved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id, challenge_id),
      FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(challenge_id) REFERENCES challenges(id)
    );
    """)
    count = conn.execute("SELECT COUNT(*) FROM challenges").fetchone()[0]
    if count == 0:
        with open(DATA_PATH, encoding="utf-8") as f:
            items = json.load(f)
        conn.executemany("""INSERT INTO challenges
          (id,code,title,category,difficulty,points,description,hint,flag_hash)
          VALUES (:id,:code,:title,:category,:difficulty,:points,:description,:hint,:flag_hash)""", items)
    conn.commit()
    conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    conn = db()
    total = conn.execute("SELECT COUNT(*) FROM challenges").fetchone()[0]
    users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    solved = conn.execute("SELECT COUNT(*) FROM solves").fetchone()[0]
    conn.close()
    return render_template("index.html", total=total, users=users, solved=solved)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if len(username) < 3 or len(username) > 24 or not username.replace("_","").isalnum():
            flash("Username must be 3–24 letters, numbers, or underscores.")
        elif len(password) < 10:
            flash("Use a password with at least 10 characters.")
        else:
            conn = db()
            try:
                conn.execute("INSERT INTO users(username,password_hash) VALUES (?,?)",
                    (username, generate_password_hash(password)))
                conn.commit()
                flash("Account created. Please sign in.")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That username is already taken.")
            finally:
                conn.close()
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        candidate = generate_password_hash(password)
        if user and hmac.compare_digest(candidate, user["password_hash"]):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("challenges_page"))
        flash("Invalid username or password.")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/challenges")
@login_required
def challenges_page():
    category = request.args.get("category","")
    difficulty = request.args.get("difficulty","")
    conn = db()
    query = """SELECT c.*, CASE WHEN s.id IS NULL THEN 0 ELSE 1 END AS solved
               FROM challenges c LEFT JOIN solves s ON s.challenge_id=c.id AND s.user_id=?"""
    params = [session["user_id"]]
    if category:
        query += " WHERE c.category=?"; params.append(category)
    if difficulty:
        query += (" AND " if " WHERE " in query else " WHERE ") + "c.difficulty=?"; params.append(difficulty)
    query += " ORDER BY c.id"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return render_template("challenges.html", challenges=rows, category=category, difficulty=difficulty)

@app.route("/challenge/<int:challenge_id>", methods=["GET","POST"])
@login_required
def challenge_detail(challenge_id):
    conn = db()
    challenge = conn.execute("SELECT * FROM challenges WHERE id=?", (challenge_id,)).fetchone()
    if not challenge:
        conn.close(); abort(404)
    solved = conn.execute("SELECT id FROM solves WHERE user_id=? AND challenge_id=?",
                          (session["user_id"], challenge_id)).fetchone()
    if request.method == "POST" and not solved:
        submitted = request.form.get("flag","").strip()
        digest = hashlib.sha256(submitted.encode()).hexdigest()
        if hmac.compare_digest(digest, challenge["flag_hash"]):
            conn.execute("INSERT OR IGNORE INTO solves(user_id,challenge_id) VALUES (?,?)",
                         (session["user_id"], challenge_id))
            conn.commit()
            flash("Correct flag! Points added.")
            solved = True
        else:
            flash("Incorrect flag. Review the clue and try again.")
    conn.close()
    return render_template("challenge.html", challenge=challenge, solved=bool(solved))

@app.route("/leaderboard")
def leaderboard():
    conn = db()
    rows = conn.execute("""SELECT u.username, COALESCE(SUM(c.points),0) AS points,
                           COUNT(s.id) AS solved
                           FROM users u LEFT JOIN solves s ON s.user_id=u.id
                           LEFT JOIN challenges c ON c.id=s.challenge_id
                           GROUP BY u.id ORDER BY points DESC, solved DESC, u.username ASC LIMIT 100""").fetchall()
    conn.close()
    return render_template("leaderboard.html", rows=rows)

@app.route("/health")
def health():
    return {"status":"ok","platform":"AMAN CYBER CTF"}

with app.app_context():
    init_db()

if __name__ == "__main__":
    # Local development only. Use a production WSGI server when deployed publicly.
    app.run(host="127.0.0.1", port=5000, debug=False)
